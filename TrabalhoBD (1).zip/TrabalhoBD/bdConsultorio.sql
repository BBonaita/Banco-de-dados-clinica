-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: clinicamedica
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `agendamentos`
--

DROP TABLE IF EXISTS `agendamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agendamentos` (
  `ID_Agendamento` int NOT NULL AUTO_INCREMENT,
  `Data_Hora` datetime NOT NULL,
  `ID_Paciente` int DEFAULT NULL,
  `ID_Recepcionista` int DEFAULT NULL,
  `Status_agend` varchar(20) NOT NULL,
  PRIMARY KEY (`ID_Agendamento`),
  KEY `ID_Paciente` (`ID_Paciente`),
  KEY `ID_Recepcionista` (`ID_Recepcionista`),
  CONSTRAINT `agendamentos_ibfk_1` FOREIGN KEY (`ID_Paciente`) REFERENCES `pacientes` (`ID_Paciente`),
  CONSTRAINT `agendamentos_ibfk_2` FOREIGN KEY (`ID_Recepcionista`) REFERENCES `recepcionistas` (`ID_Recepcionista`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agendamentos`
--

LOCK TABLES `agendamentos` WRITE;
/*!40000 ALTER TABLE `agendamentos` DISABLE KEYS */;
INSERT INTO `agendamentos` VALUES (1,'2024-07-01 09:00:00',1,1,'Confirmado'),(2,'2024-07-02 10:00:00',2,2,'Pendente'),(3,'2024-07-03 11:00:00',3,3,'Cancelado'),(4,'2024-07-04 13:00:00',4,4,'Confirmado'),(5,'2024-07-05 14:00:00',5,5,'Pendente'),(6,'2024-07-06 08:00:00',6,6,'Confirmado'),(7,'2024-07-07 09:00:00',7,7,'Pendente'),(8,'2024-07-08 10:00:00',8,8,'Confirmado');
/*!40000 ALTER TABLE `agendamentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consultas`
--

DROP TABLE IF EXISTS `consultas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consultas` (
  `ID_Consulta` int NOT NULL AUTO_INCREMENT,
  `Data_Hora` datetime NOT NULL,
  `ID_Paciente` int DEFAULT NULL,
  `ID_Medico` int DEFAULT NULL,
  `Motivo` text,
  PRIMARY KEY (`ID_Consulta`),
  KEY `ID_Paciente` (`ID_Paciente`),
  KEY `ID_Medico` (`ID_Medico`),
  CONSTRAINT `consultas_ibfk_1` FOREIGN KEY (`ID_Paciente`) REFERENCES `pacientes` (`ID_Paciente`),
  CONSTRAINT `consultas_ibfk_2` FOREIGN KEY (`ID_Medico`) REFERENCES `medicos` (`ID_Medico`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consultas`
--

LOCK TABLES `consultas` WRITE;
/*!40000 ALTER TABLE `consultas` DISABLE KEYS */;
INSERT INTO `consultas` VALUES (1,'2024-07-01 10:00:00',1,1,'Dor no peito'),(2,'2024-07-02 11:00:00',2,2,'Febre'),(3,'2024-07-03 14:00:00',3,3,'Cefaleia'),(4,'2024-07-04 15:00:00',4,4,'Dor nas costas'),(5,'2024-07-05 16:00:00',5,5,'Dores musculares'),(6,'2024-07-06 09:00:00',6,6,'Consulta de rotina'),(7,'2024-07-07 10:00:00',7,7,'Acompanhamento de tratamento'),(8,'2024-07-08 11:00:00',8,8,'Exame de rotina'),(9,'2024-07-09 13:00:00',1,2,'Dor de cabeça'),(10,'2024-07-10 14:00:00',2,3,'Gripe'),(11,'2024-07-11 15:00:00',3,4,'Artrite'),(12,'2024-07-12 16:00:00',4,5,'Tontura'),(13,'2024-07-13 17:00:00',5,6,'Asma'),(14,'2024-07-14 18:00:00',6,7,'Bronquite'),(15,'2024-07-15 10:00:00',7,8,'Hipertensão'),(16,'2024-07-16 11:00:00',8,1,'Diabetes'),(17,'2024-07-17 12:00:00',1,2,'Insônia'),(18,'2024-07-18 13:00:00',2,3,'Sinusite');
/*!40000 ALTER TABLE `consultas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicos`
--

DROP TABLE IF EXISTS `medicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicos` (
  `ID_Medico` int NOT NULL AUTO_INCREMENT,
  `Nome` varchar(100) NOT NULL,
  `Especialidade` varchar(50) NOT NULL,
  `CRM` varchar(20) NOT NULL,
  `Telefone` varchar(15) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID_Medico`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicos`
--

LOCK TABLES `medicos` WRITE;
/*!40000 ALTER TABLE `medicos` DISABLE KEYS */;
INSERT INTO `medicos` VALUES (1,'Dr. Luiz Almeida','Cardiologia','123456','567890123','luiz.almeida@gmail.com'),(2,'Dra. Fernanda Lima','Pediatria','654321','678901234','fernanda.lima@gmail.com'),(3,'Dr. Ricardo Mendes','Ortopedia','789012','789012345','ricardo.mendes@gmail.com'),(4,'Dra. Patricia Castro','Dermatologia','890123','890123456','patricia.castro@gmail.com'),(5,'Dr. Marcos Pereira','Neurologia','901234','901234567','marcos.pereira@gmail.com'),(6,'Dr. João Silva','Gastroenterologia','345678','345678901','joao.silva@gmail.com'),(7,'Dra. Ana Paula','Oftalmologia','456789','456789012','ana.paula@gmail.com'),(8,'Dr. Carlos Moreira','Psiquiatria','567890','567890123','carlos.moreira@gmail.com');
/*!40000 ALTER TABLE `medicos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pacientes`
--

DROP TABLE IF EXISTS `pacientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pacientes` (
  `ID_Paciente` int NOT NULL AUTO_INCREMENT,
  `Nome` varchar(100) NOT NULL,
  `Data_Nasc` date NOT NULL,
  `Sexo` char(1) NOT NULL,
  `Telefone` varchar(15) DEFAULT NULL,
  `Endereco` varchar(255) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID_Paciente`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pacientes`
--

LOCK TABLES `pacientes` WRITE;
/*!40000 ALTER TABLE `pacientes` DISABLE KEYS */;
INSERT INTO `pacientes` VALUES (1,'João Silva','1985-01-15','M','123456789','Rua Santa Casa, 164 - Santa Casa','joao.silva@gmail.com'),(2,'Maria Oliveira','1990-02-20','F','987654321','Rua Irlanda, 228 - Novo Mundo','maria.oliveira@gmail.com'),(3,'Carlos Santos','1975-03-30','M','234567890','Rua Campos Gerais, 293 - Coimbras','carlos.santos@gmail.com'),(4,'Sheila Pinto','1988-04-10','F','345678901','Rua Montes Claros, 260 - Jardim Primavera','sheila.pinto@gmail.com'),(5,'Pedro Souza','1995-05-25','M','456789012','Rua Mogiana, 194 - Coimbras','pedro.souza@gmail.com'),(6,'Gabriela Mendonça','1987-05-13','M','121234322','Rua Americana, 102 - Centro','gabriele.mendonza@gmail.com'),(7,'Mary Poppins','1950-02-10','F','121235333','Rua Novo Horizonte, 666 - Novo Horizonte','mary.poppins@gmail.com'),(8,'Douglas Mendes','1980-10-07','M','121236344','Rua Campina, 111 - Campina','douglas.mendes@gmail.com');
/*!40000 ALTER TABLE `pacientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prontuarios`
--

DROP TABLE IF EXISTS `prontuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prontuarios` (
  `ID_Prontuario` int NOT NULL AUTO_INCREMENT,
  `ID_Paciente` int DEFAULT NULL,
  `Data_consulta` date NOT NULL,
  `Diagnostico` text,
  `Tratamento` text,
  `Observacoes` text,
  PRIMARY KEY (`ID_Prontuario`),
  KEY `ID_Paciente` (`ID_Paciente`),
  CONSTRAINT `prontuarios_ibfk_1` FOREIGN KEY (`ID_Paciente`) REFERENCES `pacientes` (`ID_Paciente`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prontuarios`
--

LOCK TABLES `prontuarios` WRITE;
/*!40000 ALTER TABLE `prontuarios` DISABLE KEYS */;
INSERT INTO `prontuarios` VALUES (1,1,'2024-07-01','Infarto Agudo do Miocárdio','Medicamentos e cirurgia','Paciente apresentou dor no peito durante a consulta.'),(2,2,'2024-07-02','Febre alta','Antipiréticos e exames','Paciente com febre persistente e sintomas de gripe.'),(3,3,'2024-07-03','Cefaleia Tensional','Analgésicos e repouso','Paciente com dores de cabeça frequentes.'),(4,4,'2024-07-04','Dor Lombar','Fisioterapia e analgésicos','Paciente relatou dor nas costas e dificuldade de movimento.'),(5,5,'2024-07-05','Dores Musculares','Repouso e anti-inflamatórios','Paciente apresentou dores generalizadas após exercício físico.'),(6,6,'2024-07-06','Exame de Rotina','Sem alterações significativas','Paciente apresentou resultados normais nos exames de rotina.'),(7,7,'2024-07-07','Acompanhamento de Tratamento','Tratamento em progresso','Paciente está em acompanhamento para hipertensão e diabetes.'),(8,8,'2024-07-08','Exame de Rotina','Sem alterações significativas','Paciente apresentou resultados normais nos exames de rotina.'),(9,1,'2024-07-09','Enxaqueca','Medicamentos específicos','Paciente relatou episódios frequentes de enxaqueca.'),(10,2,'2024-07-10','Gripe','Antivirais e repouso','Paciente apresentou sintomas de gripe e febre alta.'),(11,3,'2024-07-11','Artrite','Medicamentos anti-inflamatórios','Paciente com dores articulares e inchaço.'),(12,4,'2024-07-12','Tontura','Investigação de causas possíveis','Paciente relatou episódios de tontura e sensação de desmaio.'),(13,5,'2024-07-13','Asma','Medicamentos broncodilatadores','Paciente com episódios de falta de ar e chiado no peito.'),(14,6,'2024-07-14','Bronquite','Antibióticos e broncodilatadores','Paciente com tosse persistente e dificuldade respiratória.'),(15,7,'2024-07-15','Hipertensão','Controle medicamentoso','Paciente está em tratamento para controle da pressão arterial.'),(16,8,'2024-07-16','Diabetes','Controle glicêmico e dieta','Paciente está em acompanhamento para controle da diabetes.'),(17,1,'2024-07-17','Insônia','Tratamento com sedativos','Paciente relatou dificuldades para dormir e insônia crônica.'),(18,2,'2024-07-18','Sinusite','Antibióticos e descongestionantes','Paciente com sintomas de sinusite e congestão nasal.');
/*!40000 ALTER TABLE `prontuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recepcionistas`
--

DROP TABLE IF EXISTS `recepcionistas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recepcionistas` (
  `ID_Recepcionista` int NOT NULL AUTO_INCREMENT,
  `Nome` varchar(100) NOT NULL,
  `Telefone` varchar(15) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID_Recepcionista`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recepcionistas`
--

LOCK TABLES `recepcionistas` WRITE;
/*!40000 ALTER TABLE `recepcionistas` DISABLE KEYS */;
INSERT INTO `recepcionistas` VALUES (1,'Alice Martins','123456789','alice.martins@gmail.com'),(2,'Bruno Alves','234567890','bruno.alves@gmail.com'),(3,'Carla Pereira','345678901','carla.pereira@gmail.com'),(4,'Diego Souza','456789012','diego.souza@gmail.com'),(5,'Elisa Costa','567890123','elisa.costa@gmail.com'),(6,'Fábio Mendes','678901234','fabio.mendes@gmail.com'),(7,'Gabriela Lima','789012345','gabriela.lima@gmail.com'),(8,'Helena Souza','890123456','helena.souza@gmail.com');
/*!40000 ALTER TABLE `recepcionistas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'clinicamedica'
--

--
-- Dumping routines for database 'clinicamedica'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-31 12:46:16
